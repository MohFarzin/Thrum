import uuid

from django.conf import settings
from django.db import models

# A pulse may sit in at most this many circuits.
MAX_CIRCUITS_PER_MONITOR = 3


class Circuit(models.Model):
    """Named cluster of monitors — dashboard pies + optional public stats page."""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="circuits",
    )
    name = models.CharField(max_length=200)
    description = models.CharField(max_length=500, blank=True, default="")
    sort_order = models.PositiveIntegerField(default=0)
    is_public = models.BooleanField(default=False)
    public_slug = models.CharField(
        max_length=32, blank=True, null=True, unique=True, default=None
    )
    # When public: include per-pulse availability bars; otherwise status pills only.
    public_show_graph = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["sort_order", "name"]
        indexes = [
            models.Index(fields=["owner"]),
            models.Index(fields=["is_public", "public_slug"]),
        ]

    def __str__(self) -> str:
        return self.name


class Monitor(models.Model):
    class Type(models.TextChoices):
        HTTP = "http", "HTTP"
        TCP = "tcp", "TCP"
        UDP = "udp", "UDP"
        HEARTBEAT = "heartbeat", "Heartbeat"

    class Status(models.TextChoices):
        UP = "up", "Up"
        DOWN = "down", "Down"
        UNKNOWN = "unknown", "Unknown"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="monitors",
    )
    circuits = models.ManyToManyField(
        Circuit,
        through="CircuitMembership",
        related_name="monitors",
        blank=True,
    )
    name = models.CharField(max_length=200)
    type = models.CharField(max_length=20, choices=Type.choices)
    target = models.CharField(
        max_length=2048,
        blank=True,
        help_text="URL for HTTP, host:port for TCP/UDP; empty for heartbeat-only.",
    )
    interval_seconds = models.PositiveIntegerField(default=60)
    timeout_seconds = models.PositiveIntegerField(default=10)
    expected_status_code = models.PositiveSmallIntegerField(default=200)
    # Optional Authorization value for HTTP checks, e.g. "Bearer …" (secret; never log).
    http_authorization = models.CharField(max_length=512, blank=True, default="")
    # When True, HTTP 200 body must be JSON with link_ok == true (WG / paired-host checks).
    http_assert_link_ok = models.BooleanField(default=False)
    heartbeat_grace_seconds = models.PositiveIntegerField(default=60)
    udp_payload = models.CharField(
        max_length=512,
        blank=True,
        default="",
        help_text=(
            "UDP payload: empty = short probe; 'bedrock' = Minecraft Bedrock RakNet ping; "
            "or hex:AABBCC…"
        ),
    )
    api_key_prefix = models.CharField(max_length=12, blank=True, default="")
    api_key_hash = models.CharField(max_length=128, blank=True, default="")
    status = models.CharField(
        max_length=20,
        choices=Status.choices,
        default=Status.UNKNOWN,
    )
    last_checked_at = models.DateTimeField(null=True, blank=True)
    last_heartbeat_at = models.DateTimeField(null=True, blank=True)
    consecutive_failures = models.PositiveIntegerField(default=0)
    is_enabled = models.BooleanField(default=True)
    is_favorite = models.BooleanField(default=False)
    favorited_at = models.DateTimeField(null=True, blank=True)
    is_public = models.BooleanField(default=False)
    # Null until share is enabled — unique allows many NULLs.
    public_slug = models.CharField(max_length=32, blank=True, null=True, unique=True, default=None)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["owner"]),
            models.Index(fields=["status"]),
            models.Index(fields=["last_checked_at"]),
            models.Index(fields=["type"]),
            models.Index(fields=["owner", "is_favorite"]),
            models.Index(fields=["is_public", "public_slug"]),
        ]

    def __str__(self) -> str:
        return f"{self.name} ({self.type})"


class CircuitMembership(models.Model):
    circuit = models.ForeignKey(
        Circuit, on_delete=models.CASCADE, related_name="memberships"
    )
    monitor = models.ForeignKey(
        Monitor, on_delete=models.CASCADE, related_name="memberships"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["circuit", "monitor"], name="uniq_circuit_monitor_membership"
            ),
        ]
        indexes = [
            models.Index(fields=["monitor"]),
            models.Index(fields=["circuit"]),
        ]

    def __str__(self) -> str:
        return f"{self.monitor_id} ∈ {self.circuit_id}"


class CheckResult(models.Model):
    monitor = models.ForeignKey(
        Monitor,
        on_delete=models.CASCADE,
        related_name="check_results",
    )
    checked_at = models.DateTimeField(auto_now_add=True)
    success = models.BooleanField()
    latency_ms = models.PositiveIntegerField(null=True, blank=True)
    error_message = models.CharField(max_length=500, blank=True, default="")
    status_code = models.PositiveSmallIntegerField(null=True, blank=True)

    class Meta:
        ordering = ["-checked_at"]
        indexes = [
            models.Index(fields=["monitor", "checked_at"]),
        ]

    def __str__(self) -> str:
        return f"{self.monitor_id} @ {self.checked_at} ok={self.success}"
